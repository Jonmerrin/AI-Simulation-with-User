class item{
  private String itemDesc;
  private String itemName;
  private String using; //Message for when you use an item
  private int uses;
  private boolean permanent; //forever use
  private boolean fixed; //can't be picked up
  private String fixederror; //to be displayed when item is fixed
  public item itemCreate;
  
  public item(){
    uses=1;
    permanent=false;
    using="You use "+itemName;
  }
  
  public void itemTemplate(){
  }
  
  public String getName(){
    return(itemName);
  }
  
  public String getDesc(){
    return(itemDesc);
  }
  
  public int checkStats(){
    return(uses);
  }
  
  public void setItemCreate(item makeItem){
    itemCreate=makeItem;
  }
  
  public void setName(String name){
    itemName=name;
  }
  
  public void setDesc(String desc){
    itemDesc=desc;
  }
  
  public void setUses(int x){
    uses=x;
  }
  
  public void setUsing(String useMessage){
    using=useMessage;
  }
  
    public void setPermanent(boolean trueFalse){
    permanent=trueFalse;
  }
  
  public String use(){
    if(uses==0){
      using="You can't use that anymore";
      return using;
    }
    if(permanent){
      using="You use "+itemName+".";
      return using;
    }
    else{
      uses=uses-1;
      if(uses==1){
        using="You use "+itemName+". You have "+uses+" "+itemName+" left.";
      }
      else{
        using="You use "+itemName+". You have "+uses+" "+itemName+"s left.";
      }
    }
      
    return using;
  }
  
  public String use(room thisRoom){
    return this.use();
  }
  
  public boolean equals(item newItem){
    return itemName.equals(newItem.getName());
  }
}