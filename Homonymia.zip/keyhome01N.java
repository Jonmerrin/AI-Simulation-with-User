class keyhome01N extends key{
  
  public String use(room thisRoom){
    String useMessage;
    if(thisRoom.getRoomName().equals("house")){
      if(thisRoom.getNorth()==false){
        useMessage="You use your house key to open the door. Why you need the key to unlock it from the inside you still don't understand.";
      }
      else{
        useMessage="You lock the door with yourself still in the apartment. A familiar problem arises.";
      }
      thisRoom.setNorth(!thisRoom.getNorth());
      return useMessage;
    }
    else if(thisRoom.getRoomName().equals("porch")){
      if(thisRoom.getSouth()==true){
        useMessage="You lock the door behind you to keep thieves away. Probably a good idea. The corner of RIAL and TUTO is notoriously unsafe neighborhood. Once, someone saw a person dressed as a car thief roaming around on halloween. Better safe than sorry.";
      }
      else{
        useMessage="You unlock the door to your house. What, did you forget something? You feel a chill run through your spine, as if all of the thieves in the neighborhood just perked up. Maybe you shouldn't have had so many Ohn-O's for breakfast.";
      }
      thisRoom.setSouth(!thisRoom.getSouth());
      thisRoom.setNorth(!thisRoom.getNorth());
      return useMessage;
    }
      else{
        useMessage="These are not the locks you're looking for.";
    return useMessage;
      }
  }
  
}