class playerHomonymia{
  
  private String playerName;
  private int hitPoints;
  
  public playerHomonymia(){
  hitPoints=100;
  }

  public int checkHealth(){
    return(hitPoints);
  }
  public String getName(){
    return(playerName);
  }
  //Should this method be in the player class, or the game? Does it make a difference?
  //Can it be used for things outside of this class?
  //No, that would make no sense, because the Strings involved are for the player class.
  public void setName(String name){
  playerName=name;
  }
  public void setHP(int newHP){
    hitPoints=newHP;
    System.out.println("Your health is now "+newHP+".");
  }
}