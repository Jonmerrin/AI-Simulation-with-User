class roomTemplate{
  private String RoomName;
  private int xLocation;
  private int yLocation;
  
  public roomTemplate(){
    xLocation=0;
    yLocation=0;
  }
}